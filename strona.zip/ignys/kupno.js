const color = new URLSearchParams(new URL(location).search).get("color");
const image = document.querySelector("#image");
const sizeInput = document.querySelector("#size");
let tshirtClass = null;
switch (color) {
  case "white":
    tshirtClass = "tees2";
    break;
  case "black":
    tshirtClass = "tees1";
    break;
  case "red":
    tshirtClass = "tees3";
    break;
  default:
    tshirtClass = "tees1";
    break;
}

function next() {
  const size = sizeInput.value;
  const tempLocation = window.location.href.split("/");
  tempLocation.splice(tempLocation.length - 1);
 
  window.location.replace(
    `${tempLocation.join("/")}/podsumowanie.html?size=${size}&color=${color}`
  );
}
