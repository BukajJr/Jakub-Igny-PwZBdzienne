const colorContainer = document.querySelector("#color");
const sizeContainer = document.querySelector("#size");
const form = document.querySelector("#form");

const color = new URLSearchParams(new URL(location).search).get("color");
const size = new URLSearchParams(new URL(location).search).get("size");

colorContainer.innerHTML = color;
sizeContainer.innerHTML = size;

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  data.append("size", size);
  data.append("color", color);
  const parsedData = {};
  for ([key, value] of data.entries()) {
    parsedData[key] = value;
  }
  alert(JSON.stringify(parsedData));
  alert("Dziekujemy za zakupy w naszym sklepie")
});
